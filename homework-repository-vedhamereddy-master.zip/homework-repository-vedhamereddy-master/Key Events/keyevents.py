# the following code will always put the screen in the top corner
import os

os.environ['SDL_VIDEO_WINDOW_POS'] = "%d, %d" % (20, 20)

from pygame import *

init()
size = width, height = 1200, 550
screen = display.set_mode(size)
button = 0
# defining colours
BLACK = (0, 0, 0)
RED = (255, 0, 0)
WHITE = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

myFont = font.SysFont("Times New Roman", 30)

# loading images
backgroundPic = image.load("background.png")
missilePic = image.load("missile.png")
tankPic = image.load("tank.png")

# scale the image
missilePic = transform.scale(missilePic, (59, 84))


def drawScene(screen):
    global missileList, shotTimer
    screen.blit(backgroundPic, Rect(0,0,width,height))

    for i in range(len(missileList) - 1, -1, -1):  # get each missile
        missiley = missileList[i]
        screen.blit(missilePic, Rect(523, missiley, 5, 5))
        missileList[i] -= 5  # move missile down 5

        if missileList[i] < -100:  # if off screen
            del missileList[i]  # delete current missile

    if time.get_ticks() - shotTimer >= 500:  # 1 second difference
        missileList.append(600)  # add new missile
        shotTimer = time.get_ticks()  # reset timer

    screen.blit(tankPic, Rect(500, 450, width, height))
    display.flip()


running = True
myClock = time.Clock()
shotTimer = time.get_ticks()  # time of last shot
missileList = [600]  # a list for missiles currently on the screen (y - values)
# Game Loop
while running:
    for e in event.get():  # checks all events that happen
        if e.type == QUIT:
            running = False
        if e.type == MOUSEBUTTONDOWN:
            mx, my = e.pos
            button = e.button

    drawScene(screen)
    myClock.tick(60)  # waits long enough to have 60 fps
    print(missileList)
quit()
