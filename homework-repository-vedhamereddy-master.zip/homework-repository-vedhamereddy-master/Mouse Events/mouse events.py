#exercise 1
from pygame import *

init()
size = width, height = 800, 600
screen = display.set_mode(size)
button = 0

BLACK = (0, 0, 0)
change = (0, 255, 0)



def drawScene(screen, button):
    draw.rect(screen, BLACK, (0, 0, width, height))
    mx, my = mouse.get_pos()
    if button == 1:
        mouse.set_visible(False)
    if button == 3:
        mouse.set_visible(True)
    draw.circle(screen, change, (mx, my), 10)
    display.flip()


running = True
myClock = time.Clock()

# Game Loop
while running:
    for e in event.get():  # checks all events that happen
        if e.type == QUIT:
            running = False
        if e.type == MOUSEBUTTONDOWN:
            button = e.button
            if change == (0, 255, 0):
                change = (255, 0, 0)
            elif change == (255, 0, 0):
                change = (0, 255, 0)


    drawScene(screen, button)
    myClock.tick(60)  # waits long enough to have 60 fps

quit()

#exercise 2
from pygame import *

init()
size = width, height = 800, 600
screen = display.set_mode(size)
button = 0

BLACK = (0, 0, 0)
GREEN = (0, 255, 0)



myClock = time.Clock()

while True:
    pos = mouse.get_pos()
    for events in event.get():
        if events.type == QUIT:
            quit()

        if events.type == MOUSEBUTTONDOWN:
            print(events.button)
            if events.button == 1:
                draw.circle(screen, GREEN, pos, 10)
            elif events.button == 3:
                screen.fill(BLACK)


    display.flip()
    myClock.tick(60)  # waits long enough to have 60 fps

quit()

#exercise 3
from pygame import *

init()
size = width, height = 800, 600
screen = display.set_mode(size)

button = 0
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
PINK = (255, 192, 203)
colourList = [GREEN, BLUE, PINK]
r = 2
draw.rect(screen, WHITE, (0, 0, 800, 600))

myClock = time.Clock()

draw.rect(screen, GREEN, (0, 0, 100, 50))
draw.rect(screen, BLUE, (101, 0, 100, 50))
draw.rect(screen, PINK, (202, 0, 100, 50))

draw.circle(screen, BLACK, (50, 175), 10)
draw.circle(screen, BLACK, (50, 275), 20)
draw.circle(screen, BLACK, (50, 375), 30)

colour = (0,0,0)
while True:
    mx, my = mouse.get_pos()
    for events in event.get():
        if events.type == QUIT:
            quit()

        if events.type == MOUSEBUTTONDOWN:
            if events.button == 1:
                if my > 0 and my < 50:
                    if mx > 0 and mx < 100:
                        colour = GREEN
                    elif mx > 100 and mx < 200:
                        colour = BLUE
                    elif mx > 200 and mx < 300:
                        colour = PINK

                if mx < 60:
                    if 180 > my >= 175:
                        r = 10
                    elif 295 > my >= 275:
                        r = 20
                    elif 405 > my >= 375:
                        r = 30

            if events.button == 1:
                if mx > 60 and my > 50:
                    draw.circle(screen, colour, (mx, my), r)
            elif events.button == 3:
                screen.fill(WHITE)

    display.flip()
    myClock.tick(60)

quit()