import os
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d, %d" %(20, 20)

from pygame import *

init()
size = width, height = 1000, 700
screen = display.set_mode(size)

#define colours
BLACK = (0, 0, 0)
RED = (255, 0, 0)
WHITE = (255, 255, 255)
background = (220, 230, 245)
boldBlue = (185, 207, 240)

#define fonts
menuFont = font.SysFont("verdana", 40)

#states in the game
STATE_MENU = 0
STATE_GAME = 1
STATE_HELP = 2
STATE_QUIT = 3

def drawMenu(screen, button, mx, my, state):
    screen.fill(background)

    blockWidth = width / 3
    blockHeight = height / 7
    rectList = [Rect(blockWidth, blockHeight, blockWidth, blockHeight), # game choice
                Rect(blockWidth, blockHeight*3, blockWidth, blockHeight), #help choice
                Rect(blockWidth, blockHeight*5, blockWidth, blockHeight)]  #quit choice
    stateList = [STATE_GAME, STATE_HELP, STATE_QUIT]
    titleList = ["Play Game", "Help", "Quit Game"]

    for i in range(len(rectList)):
        rect = rectList[i]
        draw.rect(screen, WHITE, rect)
        text = menuFont.render(titleList[i], 1, boldBlue)
        textWidth, textHeight = menuFont.size(titleList[i])
        useW = (blockWidth - textWidth)/2
        useH = (blockHeight - textHeight)/2
        textRect = Rect(rect[0] + useW, rect[1] + useH, textWidth, textHeight)
        screen.blit(text, textRect)
        if rect.collidepoint(mx, my):
            draw.rect(screen, boldBlue, rect, 4)
            if button == 1:
                state = stateList[i]
                print("state has been changed to", state)
    return state


def drawGame(screen, button, mx, my, state):
    screen.fill(background)
    if button == 3:
        state = STATE_MENU
    return state
    #text = myFont.render(string, 1, RED)
    #size = myFont.size(string)
    #screen.blit(text, Rect(mx, my, size[0], size[1]))

def drawHelp(screen, button, mx, my, state):
    screen.fill(background)
    if button == 3:
        state = STATE_MENU
    return state
    #text = myFont.render(string, 1, RED)
    #size = myFont.size(string)
    #screen.blit(text, Rect(mx, my, size[0], size[1]))


running = True
myClock = time.Clock()

#initialize variables
state = STATE_MENU
mx = my = 0

# Game Loop
while running:
    button = 0
    for e in event.get():  # checks all events that happen
        if e.type == QUIT:
            running = False
        if e.type == MOUSEBUTTONDOWN:
            mx, my = e.pos
            button = e.button
        elif e.type == MOUSEMOTION:
            mx, my = e.pos
            #button = e.button
    if state == STATE_MENU:
        state = drawMenu(screen, button, mx, my, state)
    elif state == STATE_GAME:
       state = drawGame(screen, button, mx, my, state)
    elif state == STATE_HELP:
        state = drawHelp(screen, button, mx, my, state)
    else:
        running = False

    display.flip()
    myClock.tick(60)  # waits long enough to have 60 fps

quit()
