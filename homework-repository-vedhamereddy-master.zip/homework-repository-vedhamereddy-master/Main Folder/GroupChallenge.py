#Vedha and Abbas
from collections import Counter
userCode = input("Insert a 3 digit number")

codeLength = (len(userCode))
new = Counter(str(userCode))

if codeLength != 3:
    print("This is not a 3 digit number")
elif (userCode[0] == '0'):
    print("Please enter a different starting digit")
elif (userCode.isdigit()) == False:
    print("Please enter only digits")
elif any(value > 1 for value in new.values()):
    print ("The number has repeating digits")
else:

    def userCode_str(str):
        str1 = ""
        for i in str:
            str1 = i + str1
        return str1


    str = userCode
    print(userCode)
    userCode_reversed = int(userCode_str(str))
    userCode_int = int(userCode)
    if userCode_int < userCode_reversed:
        print(userCode_reversed - userCode_int)
    else:
        print(userCode_int - userCode_reversed) 
