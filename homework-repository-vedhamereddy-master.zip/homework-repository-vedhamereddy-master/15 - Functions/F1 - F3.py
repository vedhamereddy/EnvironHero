import math
import math
#exercise 1
"the output of this program is the (5+7) * (14-8) = 72"

#exercise 2
def printStars():
   print(55*"*")

def lineOfStars(n):
   print(n*"*")

userInput = int(input("How many asteriks would you like to see?: "))
printStars()
lineOfStars(userInput)
printStars()

#exercise 3
def slopeCalc(x1,x2,y1,y2):
    return (y2 - y1)/(x2 - x1)
def distanceCalc(x1,x2,y1,y2):
    return math.sqrt((x2-x1)**2 + (y2-y1)**2)
def stringConvert(orderedPair):
    first = orderedPair[1]
    second = orderedPair[3]
    a = int(first)
    b = int(second)
    return a,b

inputFirst = input("Enter the first coordinate in the following format (x,y): ")
first = stringConvert(inputFirst)
x1 = first[0]
y1 = first[1]

inputSecond = input("Enter the second coordinate in the following format (x,y): ")
second = stringConvert(inputSecond)
x2 = second[0]
y2 = second[1]

distance = distanceCalc(x1,x2,y1,y2)
print("The distance between the points", inputFirst, "and", inputSecond, "is", distance)

slope = slopeCalc(x1,x2,y1,y2)
print("the slope between the points", inputFirst, "and", inputSecond, "is", slope)










