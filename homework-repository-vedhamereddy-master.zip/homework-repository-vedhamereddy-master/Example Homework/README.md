# Notes (New File)

See the above ```newFile.py``` file for a template on how your files should be created to start.  The main portion of this is the header at the top of the file.
