#exercise 1
list = []
length = 10

for i in range(length):
    number = int(input("Please enter a digit: "))
    list.append(number)

list.sort()
for numb in list:
    print(numb, end="\t")

length % 2 == 0
middle = length // 2
median = (list[middle - 1] + list[middle]) / 2

print("\n","the median is", median)


#exercise 2
list = []

for i in range(5):
    name = input("Please enter a name: ")
    list.append(name)

list.sort()
for name in list:
    print(name)


#exercise 3
list1 = [13, 15, 23, 27, 31]
list2 = [10, 20, 30, 40, 50, 60, 70]

list3 = list1 + list2
print(list3)

newList = []

while list3:
    min = list3[0]
    for x in list3:
        if x < min:
            min = x
    newList.append(min)
    list3.remove(min)

print(newList)


#exercise 4
import random
suits = ["Clubs", "Diamonds", "Hearts", "Spades"]
values = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"]
deck = []
for s in suits:
    for v in values:
        deck.append(v + " of " + s)

random.shuffle(deck)
hand = deck[:5]
print(hand)


#exercise 5
import random
friends = ["Jo", "Bo", "Mo", "Lo", "Fo"]
emotions = ["tolerates", "annoys", "bothers", "runs away from", "chases"]

for i in friends:
    curEmotion = random.choice(emotions)
    curFriend = random.choice(friends)
    print(i, curEmotion, curFriend)


#exercise 6
fruit = ["Apple", "Orange", "Banana", "Grape", "Mango"]
prices = [0.45, 1.25, 0.75, 0.35, 0.52]

print("Fruit\t\t\t\tPrice")
print("="*28)
for i in range(len(fruit)):
    print(fruit[i],"\t\t\t\t $", prices[i])

#exercise 7
import random
myList = []

for i in range(1000):
    number = random.randint(1, 6) + random.randint(1, 6)
    myList.append(number)

for i in range(2, 13):
    print('Sum of', i, 'was rolled', myList.count(i), 'times')

