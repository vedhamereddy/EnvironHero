#exercise 1
for count in range(1,11):
    print(count)

#exercise 2
number = int(input("Please enter a number: "))
sum = 0
for count in range(1,number+1):
    sum = sum+count
    print(sum)

#exercise 3
for count in range(1500,2701):
    if count %5 == 0 or count %7 == 0:
        print(count)

#exercise 4
for count in range(1,6):
    for countTwo in range(1,count+1):
        print(countTwo, end="")
    print()
