#exercise 1
for count in range(1,101):
    print(count)

#exercise 2
for count in range(20,41):
    if count %2 == 0:
        print(count)

#exercise 3
for count in reversed(range(21,31)):
    if count %2 != 0:
        print(count)

#exercise 4
firstDigit = int(input("Please enter the first digit in the range"))
secondDigit = int(input("Please enter the second digit in the range"))

if firstDigit < secondDigit:
    for count in range(firstDigit,secondDigit+1):
        print(count)
if firstDigit > secondDigit:
    for count in reversed(range(secondDigit, firstDigit+1)):
        print(count)