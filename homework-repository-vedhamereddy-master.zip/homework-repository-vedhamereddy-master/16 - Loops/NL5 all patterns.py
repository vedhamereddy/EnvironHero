#exercise 5 pattern 1
num = 10
row = 0
while row < num:
  stars = row + 1
  while stars > 0:
      print("*",end=" ")
      stars = stars - 1
  row = row +1
  print()


#exercise 5 pattern 2
rows = 10
for count in range (0,rows):
   for i in range (rows,count,-1):
       print("* ", end="")
   print()

#exercise 5 pattern 3
for count in range(1,11):
   for countTwo in range(1,count+1):
       print(countTwo, end=" ")
   print()

#exercise 5 pattern 4
for count in reversed(range(1,11)):
    for countTwo in reversed(range(1,count+1)):
        print(countTwo, end=" ")
    print()