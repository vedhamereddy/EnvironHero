from random import choice
from collections import Counter
import random

#exercise 1
flip = [choice(['heads','tails']) for count in range(300)]
number = Counter(flip)
heads = number['heads']
tails = number['tails']
print("total number of heads:", heads)
print("total number of tails:", tails)

#exercise 2
ftotal = 0

for count in range(1000):
    num = random.randint(1, 6)
    if num == 5:
        ftotal += 1
print(ftotal)

#exercise 3
ftotal = 0

for count in range(1000):
    d1 = random.randint(1, 6)
    d2 = random.randint(1, 6)
    if d1 == d2:
        ftotal += 1
print(ftotal)

#exercise 4
numbtimes = 0
dice = random.randint(1, 6)
while True:
    dice2 = random.randint(1, 6)
    numbtimes += 1
    if dice2 == dice:
        break
print(numbtimes)

#exercise 5
suits = ["hearts", "diamonds", "clubs", "spades"]
cards = ["ace", "2", "3", "4", "5", "6", "7", "8", "9", "10","jack", "queen", "king"]

for count in range(1):
    suit = random.choice(suits)
    card = random.choice(cards)
    print("Dealt the", card, "of", suit)

#exercise 6
compnum = random.randint(1, 100)
guesses = 0

while True:
    guess = int(input("Please enter your guess."))
    guesses += 1
    if guess == compnum:
        print("this was the correct guess, you got it in", guesses, "guesses")
        break
    elif guess < compnum:
        print("the number entered is too low")
    else:
        print("the number entered is too high")

