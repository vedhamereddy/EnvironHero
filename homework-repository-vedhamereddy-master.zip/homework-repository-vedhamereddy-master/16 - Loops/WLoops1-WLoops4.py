#exercise 1
count = 0

while count <= 99:
    count += 1
    print(count)

#exercise 2
while True:
    colours = input("Enter a colour (for the last entry please type 'done'): ")
    if colours == "done":
        break

#exercise 3
count = 0
total = 0

while True:
    age = int(input("Input age of family member <-1 to exit> "))
    if age == -1:
        break
    count += 1
    total += age

print ("The average is", total / count)

#exercise 4
number = int(input("Please enter a number: "))
string = number
amnt = 0
while number > 1:
    number = number / 2
    amnt = amnt + 1
print(string, "is divisible by two,",amnt, "times.")


