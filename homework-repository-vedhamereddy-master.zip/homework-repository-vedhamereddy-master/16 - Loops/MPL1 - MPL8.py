#exercise 1
num = 0

for count in range(0,101):
   if count %2 == 0:
       num += count
print ("the sum is", num)

#exercise 2
ttl = 0

number1 = int(input("Please enter a number: "))
number2 = int(input("Please enter a second number: "))

if num1 <= num2:
   for count in range(number1, number2 + 1):
       ttl += count
else:
   for count in range(number2, number1 + 1):
       ttl += count

print("The sum is", ttl)

#exercise 3
count = 0
total = 0

while True:
   grade = int(input("Input student's grade (type a mark less than 0 to exit)"))
   if grade <= 0:
       break
   count += 1
   total += grade
print ("The average is", total / count)

#exercise 4
total = 0
num1 = int(input("please enter the first number: "))
num2 = int(input("please enter the second number: "))

for count in range(num1,num2+1):
   total += count

print ("The sum is", total)

#exercise 5
num = input("please enter a number: ")

product = 1
for digit in num:
   if int(digit) % 2 == 1:
       product = product * int(digit)

print("Product of the digits is", product)

#exercise 6
string = input("please enter a string: ")
length = len(string)
for count in range(length):
   secondcol = length - count - 1
   print(string[count], string[secondcol])

#exercise 7
word = input("please enter a word: ")

for count in range(len(word)):
   print(word[count:]+word[0:count])

#exercise 8
sentence = input("please enter a sentence: ")
words = sentence.split()
for i in words:
 print(i)


