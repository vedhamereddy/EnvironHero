# the following code will always put the screen in the top corner
import os

os.environ['SDL_VIDEO_WINDOW_POS'] = "%d, %d" % (20, 20)

from pygame import *

init()
size = width, height = 1200, 550
screen = display.set_mode(size)
button = 0
# defining colours
BLACK = (0, 0, 0)
RED = (255, 0, 0)
WHITE = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

running = True

# movement key booleans
PRESS_RIGHT = False
PRESS_LEFT = False
PRESS_UP = False
PRESS_DOWN = False

myFont = font.SysFont("Times New Roman", 30)

# loading images
backgroundPic = image.load("background.png")
missilePic = image.load("missilepng.png")
tankPic = image.load("tank.png")
shipPic = image.load("car.png")

# scale the image
missilePic = transform.scale(missilePic, (23, 83))
shipPic = transform.scale(shipPic, (55, 100))


def drawScene(screen, shipx, shipy):
    global missileList, shotTimer
    screen.blit(backgroundPic, Rect(0,0,width,height))
    shipRect = Rect(shipx, shipy, shipPic.get_width(), shipPic.get_height())
    screen.blit(shipPic, shipRect)
    draw.rect(screen, RED, shipRect, 1)

    for i in range(len(missileList) - 1, -1, -1):  # get each missile
        missiley = missileList[i]
        missileRect = Rect(540, missiley,missilePic.get_width(), missilePic.get_height())
        draw.rect(screen, RED, missileRect, 1)
        screen.blit(missilePic, Rect(540, missiley, 5, 5))
        missileList[i] -= 5  # move missile down 5

        if missileList[i] < -100:  # if off screen
            del missileList[i]  # delete current missile

        if missileRect.colliderect(shipRect) == 1:
            return False

    if time.get_ticks() - shotTimer >= 500:  # 1 second difference
        missileList.append(600)  # add new missile
        shotTimer = time.get_ticks()  # reset timer

    screen.blit(tankPic, Rect(500, 450, width, height))

    display.flip()
    return True



myClock = time.Clock()
shotTimer = time.get_ticks()  # time of last shot
missileList = [600]  # a list for missiles currently on the screen (y - values)
shipx = 0
shipy = 0
moveRate = 1

# Game Loop
while running:
    for e in event.get():  # checks all events that happen
        if e.type == QUIT:
            running = False
        elif e.type == MOUSEBUTTONDOWN:
            mx, my = e.pos
            button = e.button
        elif e.type == KEYDOWN:
            if e.key == K_RIGHT:
                PRESS_RIGHT = True
            if e.key == K_LEFT:
                PRESS_LEFT = True
            if e.key == K_UP:
                PRESS_UP = True
            if e.key == K_DOWN:
                PRESS_DOWN = True
        elif e.type == KEYUP:
            if e.key == K_RIGHT:
                PRESS_RIGHT = False
            if e.key == K_LEFT:
                PRESS_LEFT = False
            if e.key == K_UP:
                PRESS_UP = False
            if e.key == K_DOWN:
                PRESS_DOWN = False

    drawScene(screen, shipx, shipy)
    myClock.tick(60)  # waits long enough to have 60 fps
    print(missileList)

    if PRESS_RIGHT == True:
        shipx += moveRate
    if PRESS_LEFT == True:
        shipx -= moveRate
    if PRESS_UP == True:
        shipy -= moveRate
    if PRESS_DOWN == True:
        shipy += moveRate

quit()
