#exercise 1
import os
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d, %d" %(20, 20)

import pygame
pygame.init()
BLUE = (0, 0, 255)
RED = (255,0,0)
GREEN = (0,255,0)
SIZE = (800, 600)
screen = pygame.display.set_mode(SIZE)
 
pygame.draw.line(screen, GREEN, (0, 0), (800, 600))
pygame.draw.line(screen, GREEN, (800, 0), (0, 600))
pygame.draw.ellipse(screen,BLUE, (50,50,700,500))
pygame.draw.rect(screen,RED,(0,0,800,600),100)

pygame.display.flip()
pygame.time.wait(100000)
pygame.quit()

#exercise 2
import os
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d, %d" %(20, 20)

import pygame
pygame.init()
BLUE = (0, 0, 255)
RED = (255,0,0)
GREEN = (0,255,0)
SIZE = (300, 300)
screen = pygame.display.set_mode(SIZE)

pygame.draw.line(screen, BLUE, (0, 0), (100,100), 10)
pygame.draw.line(screen, BLUE, (0, 100), (100,0), 10)

pygame.draw.line(screen, BLUE, (100, 0), (200,100), 10)
pygame.draw.line(screen, BLUE, (100, 100), (200,0), 10)

pygame.draw.circle(screen, GREEN,(255,50),45,5)
pygame.draw.circle(screen, GREEN,(255,150),45,5)
pygame.draw.circle(screen, GREEN,(255,250),45,5)

pygame.draw.line(screen, RED, (0, 100), (300,100), 10)
pygame.draw.line(screen, RED, (0, 200), (300,200), 10)
pygame.draw.line(screen, RED, (100, 0), (100,300), 10)
pygame.draw.line(screen, RED, (200, 0), (200,300), 10)


pygame.display.flip()
pygame.time.wait(100000)
pygame.quit()

#exercise 5
import os
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d, %d" %(20, 20)

import pygame
pygame.init()
BLUE = (0, 0, 255)
RED = (255,0,0)
GREEN = (0,255,0)
SIZE = (500, 500)
screen = pygame.display.set_mode(SIZE)
screen.fill(BLUE)

pygame.draw.rect(screen,GREEN,(200,200,100,100))


pygame.display.flip()
pygame.time.wait(100000)
pygame.quit()

