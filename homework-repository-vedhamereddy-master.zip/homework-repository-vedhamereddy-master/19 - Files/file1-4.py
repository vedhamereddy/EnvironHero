#exercise 1
numFile = open ("in.txt", "w")
user = True
while user == True:
    num = int(input("Please enter a positive number. (-1 to finish)"))
    if num < 0:
        user = False
    else:
        numFile.write(str(num) + "\n")
numFile.close()

numFile = open("in.txt", "r")
myList = []
while True:
    text = numFile.readline()
    text = text.rstrip("\n")
    if text == "":
        break
    myList.append(int(text))

numFile.close()

for number in myList:
    print(2 * number, end="\n")

#exercise 2
# Reading from a file
numFile = open("ages.text", "r")
agesList = []
while True:
    text = numFile.readline()
    text = text.rstrip("\n")
    if text == "":
        break
    info = text.split(" ")
    agesList.append(int(info[1]))

numFile.close()

sum = 0
for age in agesList:
    sum += age

average = sum / len(agesList)
print(f'The average age is {average}')

#exercise 3
numFile = open("file.txt", "r")

firstNameList = []
lastNameList = []
mathList = []
engList = []
scienceList = []
compList = []

while True:
    text = numFile.readline()
    text = text.rstrip("\n")
    if text == "":
        break
    info = text.split(" ")
    fNameList.append(info[0])
    lNameList.append(info[1])
    mathList.append(int(info[2]))
    engList.append(int(info[3]))
    scienceList.append(int(info[4]))
    compList.append(int(info[5]))

numFile.close()

print("First\t\tLast\t\tMath\tEnglish\tScience\tComputers\tAverage")
print(60 * "=")
for i in range(len(fNameList)):
    average = (mathList[i] + engList[i] + scienceList[i] + compList[i]) / 4
    print("%-10s\t%-10s\t%3i\t  %3i\t  %3i\t  %3i\t\t%5.1f"
          % (fNameList[i], lNameList[i], mathList[i], engList[i], scienceList[i], compList[i], average))

#exercise 4
import random

numFile = open("random.txt", "w")
numNums = random.randint(1, 10000)

for i in range(numNums):
    num = random.randint(1, 1000)
    numFile.write(str(num) + "\n")

numFile.close()

#exercise 5 (im having a bit of trouble with this one)

