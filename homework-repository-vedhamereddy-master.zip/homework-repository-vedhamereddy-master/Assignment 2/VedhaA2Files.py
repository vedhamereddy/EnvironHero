'''
Vedha Mereddy,
December 16th 2020,
ICS3U1,
Ms.Bokhari,
The program is a card deck game occuring between two players
I used code from the previous files exercises as well as youtube videos
'''
#App Level 2
import random

#reads the CSV file named ranks.txt
ranksFile = open("ranks.txt", "r")

# list fields
rank = []
power = []
number = []
listOfLists = []

while True:
    text = ranksFile.readline()
    text = text.rstrip("\n")
    if text=="":
        break
    info = text.split(",")
    rank.append(info[0])
    power.append(int(info[1]))
    number.append(int(info[2]))

#collect all data into a list
listOfLists.append(rank)
listOfLists.append(power)
listOfLists.append(number)

print('Rank                Skill               Number\n'+'='*47)
#format data in table
row_format = '{:<20}' * len(listOfLists)
for i in zip(*listOfLists):
    print(row_format.format(*i))
print('\n')

#App Level 3
#creates the deck based on all ranks and numbers
deck = [a for a,b in zip(rank,number) for _ in range(b)]
print('='*47,'\n            Level 3 Build Deck \n'+'='*47)
print(deck)
print('\n')

print('='*47,'\n            Level 3 Dealing \n'+'='*47)
#empty list fields
player1 = []
player2 = []
#shuffle deck
random.shuffle(deck)

#rotate between player 1 and 2 and deal out cards
for i in range(len(deck)):
    if i % 2 == 0:
        print(f'Player 1 is dealt: {deck[i]}')
        player1.append(deck[i])
    elif i % 2 == 1:
        print(f'Player 2 is dealt: {deck[i]}')
        player2.append(deck[i])
print()
#displays the hands of player 1 and 2
print(f'Player 1 Deck:{player1}')
print(f'Player 2 Deck:{player2}')
print('\n')

#App Level 4
print('='*47,'\n              Level 4 Playing \n'+'='*47)
#duplicate player 1 and 2 deck
playerOne = []
playerTwo = []
playerOne = list(player1)
playerTwo = list(player2)

#function to assign rank to card name
def give_rank (playerDeck,cardName,cardRank):
    for i in range(len(playerDeck)):
        if playerDeck[i] == cardName:
            playerDeck[i] = cardRank

#give rank to all card types in both decks
give_rank(player1,'Private',1)
give_rank(player2,'Private',1)
give_rank(player1,'Corporal',3)
give_rank(player2,'Corporal',3)
give_rank(player1,'Sergeant',5)
give_rank(player2,'Sergeant',5)
give_rank(player1,'Lieutenant',7)
give_rank(player2,'Lieutenant',7)
give_rank(player1,'Captain',10)
give_rank(player2,'Captain',10)
give_rank(player1,'Major',15)
give_rank(player2,'Major',15)
give_rank(player1,'Colonel',20)
give_rank(player2,'Colonel',20)
give_rank(player1,'General',25)
give_rank(player2,'General',25)
give_rank(player1,'Admiral',30)
give_rank(player2,'Admiral',30)

#lists to track number of cards in each players deck
overflow = []
first = []
second = []

loopLen = len(player1)
#have loop running while both decks still have cards
for count in range(loopLen):
    if player1[0] == player2[0]:
        #add cards to overflow deck when tied
        overflow.append(playerOne[0])
        overflow.append(playerTwo[0])
        print(f'This is a tie, both players drew a {playerOne[0]}, these have been added to the overflow deck')
        #remove cards from both deck so index[0] = next card in deck
        player1.pop(0)
        player2.pop(0)
        playerOne.pop(0)
        playerTwo.pop(0)

    elif player1[0] > player2[0]:
        #add cards to player1's (bottom) deck when they win
        first.append(playerOne[0])
        first.append(playerTwo[0])
        print(f'{playerOne[0]} beats {playerTwo[0]}, cards go to Player 1')
        #remove cards from both deck so index[0] = next card in deck
        player1.pop(0)
        player2.pop(0)
        playerOne.pop(0)
        playerTwo.pop(0)

    elif player1[0] < player2[0]:
        #add cards to player2's (bottom) deck when they win
        second.append(playerOne[0])
        second.append(playerTwo[0])
        print(f'{playerTwo[0]} beats {playerOne[0]}, cards go to Player 2')
        #remove cards from both deck so index[0] = next card in deck
        player1.pop(0)
        player2.pop(0)
        playerOne.pop(0)
        playerTwo.pop(0)

print('Game Over.')
print('\n')

print('='*47,'\n            Level 4 Game Summary\n'+'='*47)
#create variables for size of every deck being measured
lengthFirst = len(first)
lengthSecond = len(second)
lengthOverflow = len(overflow)

#track when and which deck, overflow cards should be added to, and print
if lengthFirst > lengthSecond:
    print(f'Player 1 has {lengthFirst + lengthOverflow} cards')
    print(f'Player 2 has {lengthSecond} cards')
    print(f'There are 0 cards in the overflow deck')

elif lengthFirst < lengthSecond:
    print(f'Player 1 has {lengthFirst} cards')
    print(f'Player 2 has {lengthSecond + lengthOverflow} cards')
    print(f'There are 0 cards in the overflow deck')

elif lengthFirst == lengthSecond:
    print(f'Player 1 has {lengthFirst} cards')
    print(f'Player 2 has {lengthSecond} cards')
    print(f'There are {lengthOverflow} cards in the overflow deck')
print()

#level 4 plus
#create new lists to track measured values
formatList = []
amountGamesList = []
amountGames = 0

#play full game 10 times as shown above without printing any values
for count in range(10):
    #increase the game number by 1 every time it loops and add the value to a list
    amountGames += 1
    amountGamesList.append(count)

    player1 = []
    player2 = []
    random.shuffle(deck)

    for i in range(len(deck)):
        if i % 2 == 0:
            player1.append(deck[i])
        elif i % 2 == 1:
            player2.append(deck[i])

    playerOne = []
    playerTwo = []
    playerOne = list(player1)
    playerTwo = list(player2)

    overflow = []
    first = []
    second = []

    loopLen = len(player1)
    for count in range(loopLen):

        if player1[0] == player2[0]:
            overflow.append(playerOne[0])
            overflow.append(playerTwo[0])
            player2.pop(0)
            playerOne.pop(0)
            playerTwo.pop(0)

        elif player1[0] > player2[0]:
            first.append(playerOne[0])
            first.append(playerTwo[0])
            player1.pop(0)
            player2.pop(0)
            playerOne.pop(0)
            playerTwo.pop(0)


        elif player1[0] < player2[0]:
            second.append(playerOne[0])
            second.append(playerTwo[0])
            player1.pop(0)
            player2.pop(0)
            playerOne.pop(0)
            playerTwo.pop(0)

    #append all lists into a big list called formatList
    formatList.append(str(len(amountGamesList)))
    formatList.append(str(len(first)))
    formatList.append(str(len(second)))
    formatList.append(str(len(overflow)))

#create a function that groups every n'th term in a list into its own list
def list_slice(a, skip):
    return [a[i::skip] for i in range(skip)]

#redefine formatLists as a list of lists that contains all the individual categories needed for the table
formatList = list_slice(formatList,4)

#create table header
print("\n" + "=" * 66)
column_names = ["Game Number", "  Player 1 Cards", " Player 2 Cards", "    Overflow Deck"]

for name in column_names:
    print(name + "\t", end="")

print("\n" + "=" * 66)

#loop through all of the lists in formatList and place them in the table
for i in range(10):
    currentRow = [val[i] for val in formatList]
    for i in range(4):
        print(currentRow[i] + "\t\t\t\t\t", end='')
    print()

#calculate averages of each column
print("Average\t\t\t\t", end='')
averages = []
for i in range(4):
    currentColumn = formatList[i]
    currentAverage = 0
    for i in range(10):
        currentAverage += int(currentColumn[i])

    currentAverage /= 10
    averages.append(currentAverage)

#print out averages of the columns at the bottom
for i in range(4):
    if i == 0:
        continue
    print(f'{averages[i]}\t\t\t\t', end='')



