#exercise 1
first = str (input("Please enter your first name: "))
last = str (input("Please enter your last name: "))
print(first[0],".",last)

#exercise 2
name = str(input("Please enter your first and last name: "))
split = name.split(" ", 1)
Last = split[1]
First = split[0]
print(Last.upper(), First.lower())

#exercise 3
filename = str(input("Please enter your file name: "))
split = filename.split(".", 1)
end = split[1]
print(".",end.lower())

#exercise 4
sentence = str(input("Please enter a sentence: "))
lines = sentence.split(' ')
print('\n'.join(lines))

#exercise 5
num = int(input("Please enter the size number: "))
print('\n'.join(['X'*num]*num))