#exercise 1
word=str(input("Please enter a word of any length: "))
piglat = (word[1:]+word[0]+'a')
print(piglat)

#exercise 2
word = str(input("Please enter a word in pig latin: "))
noa = word[:-1]
newword = noa[-1] + noa[:-1]
print(newword)

#exercise 3
word = str(input("Please enter a word: "))
newword = (word[-1] + word[:-1] + 'mouse')
print(newword)

#exercise 4
word = str(input("Please enter a word in Van Rooyen Speak: "))
nomouse = word[:-5]
word2 = word[:-5]
word3 = (nomouse.replace(nomouse[0],''))
print(word3 + word2[0])

