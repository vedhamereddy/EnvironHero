import os
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d, %d" %(20, 20)
from pygame import *

init()
size = width, height = 1536, 659
screen = display.set_mode(size)
button = 0
BLACK = (0, 0, 0)
RED = (255, 255, 255)
myFont = font.SysFont("Times New Roman", 30)

# loading images
backgroundPic = image.load("background.jpg")
charPic = image.load("character.png")
# scale the image
backgroundPic = transform.scale(backgroundPic, (width, height))


def drawScene(screen, backx, manX, manY):

    screen.blit(backgroundPic, Rect(backx,0,width,height))
    screen.blit(backgroundPic, Rect(backx + width - 70, 0, width, height))
    screen.blit(charPic, (manX, manY))

    display.flip()


running = True
myClock = time.Clock()
backgroundX = 0
manX = 0
manY = 350

# Game Loop
while running:
    for e in event.get():  # checks all events that happen
        if e.type == QUIT:
            running = False
        if e.type == MOUSEBUTTONDOWN:
            mx, my = e.pos
            button = e.button

    drawScene(screen, backgroundX, manX, manY)

    backgroundX -= 1
    if backgroundX < -1*width:
        backgroundX = 0
    myClock.tick(60)  # waits long enough to have 60 fps
    manX += 1

quit()
