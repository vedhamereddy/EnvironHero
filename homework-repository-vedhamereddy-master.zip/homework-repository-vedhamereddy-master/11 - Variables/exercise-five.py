P= 10000
n = 12
r = 0.08
t = int(input("Please enter the number of years that the money will be compounded for."))
math = P*(1+(r/n))**(n*t)
print(math)