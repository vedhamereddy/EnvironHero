#Add parenthesis to the expression 6 * 1 - 2 to change its value from 4 to -6.
math = 6*(1-2)
print(math)