bruce = 6
answer = bruce + 4
print(answer)