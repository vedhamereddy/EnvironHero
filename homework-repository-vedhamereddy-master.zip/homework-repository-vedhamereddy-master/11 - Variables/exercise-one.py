#All work and no play makes Jack a dull boy
one = "All"
two = "work"
three = "and"
four = "no"
five = "play"
six = "makes"
seven = "Jack"
eight = "a"
nine = "dull"
ten = "boy"
print(one,two, three, four, five, six, seven, eight, nine, ten)