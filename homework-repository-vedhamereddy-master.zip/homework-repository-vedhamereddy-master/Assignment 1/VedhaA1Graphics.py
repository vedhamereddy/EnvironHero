'''
Vedha Mereddy,
December 4th 2020,
ICS3U1,
Ms.Bokhari,
The program produces a drawing of animals celebrating the christmas holidays outside in the snow
I used a lot of youtube videos as a reference on creating the illusion of movement of the snow fall. All my images were taken from Canva's image library.
'''

#import libraries and setup screen
import pygame
import random
pygame.init()
screen = pygame.display.set_mode((1000, 700))

#variables
snowWhite = (239, 232, 211)
lightWhite = (227, 220, 197)
#empty array for snow coordinates
snow_array = []

#load images
img2=pygame.image.load('b.png')
img3=pygame.image.load('c.png')
img4=pygame.image.load('d.png')
img5=pygame.image.load('e.png')
img6=pygame.image.load('f.png')
img7=pygame.image.load('g.png')
img8=pygame.image.load('h.png')
img9=pygame.image.load('Untitled Design (1).png')
red=pygame.image.load('redlights__1_-removebg-preview.png')
blue=pygame.image.load('bluelights-removebg-preview.png')
green=pygame.image.load('greenlights-removebg-preview.png')


def draw_house(x, y):
    #grey brick house
    pygame.draw.rect(screen, (182, 183, 173), (x, y-100, 400, 300))
    #light brown door
    pygame.draw.rect(screen, (175, 143, 115), (x+160, y+50, 90, 150))
    #dark brown door knob
    pygame.draw.circle(screen, (130, 105, 83), (x+230, y+130), 8)
    #dark gray triangle roof
    pygame.draw.polygon(screen, (92, 94, 101), ((x, y-100), (x+200, y-250), (x+400, y-100)))
    #apply window function
    draw_window(x+30, y-30)
    draw_window(x+290, y-30)

def draw_window(x, y):
    #glass
    pygame.draw.rect(screen, (255, 255, 255), (x, y-50, 80, 140))
    #frame
    pygame.draw.rect(screen, (84, 168, 138), (x, y-50, 80, 140), 5)
    pygame.draw.rect(screen, (84, 168, 138), (x+35, y-50, 5, 140))
    pygame.draw.rect(screen, (84, 168, 138), (x, y-20, 80, 5))

#this function simplifies the placement and sizing of images
def place_img(imgName, x, y, w, l):
   imgName=pygame.transform.scale(imgName, (w, l))
   screen.blit(imgName, (x, y))

#simplifies christmas light placement
def christmas_light(colourName):
    place_img(colourName, 530, 390, 242, 170)
    place_img(colourName, 330, 390, 242, 170)


while True:
    # background image
    place_img(img9, 0, 0, 1000, 700)

    # draws the house
    draw_house(330, 499)

    # snow falling animation
    for i in range(2):
        x = random.randrange(0, 1000)
        y = random.randrange(0, 700)
        snow_array.append([x, y])
    for count in range(len(snow_array)):

        # draws the snow flake
        pygame.draw.circle(screen, (255, 255, 255), snow_array[count], 1)

        # moves the snow down one pixel
        snow_array[count][1] += 1

    # placing all background animals and decorations
    place_img(img2, 220, 500, 100, 128)
    place_img(img3, 50, 530, 128, 128)
    place_img(img4, 650, 550, 128, 150)
    place_img(img5, 842, 550, 85, 137)
    place_img(img6, 40, 300, 181, 181)
    place_img(img7, 440, 550, 43, 69)
    place_img(img7, 580, 550, 43, 69)
    place_img(img8, 475, 440, 100, 105)

    # christmas lights
    lights = random.choice(['red', 'blue', 'green'])

    if lights == 'red':
        christmas_light(red)

    if lights == 'blue':
        christmas_light(blue)

    if lights == 'green':
        christmas_light(green)


    pygame.display.flip()
    pygame.time.Clock().tick(100)

pygame.quit()
