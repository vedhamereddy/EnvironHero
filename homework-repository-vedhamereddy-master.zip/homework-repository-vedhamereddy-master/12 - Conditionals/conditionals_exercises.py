#exercise 1
number = int(input("Please enter the day number (values must be between 0 and 6)."))
if number == 0:
   print("Sunday")
if number == 1:
   print("Monday")
if number == 2:
   print("Tuesday")
if number == 3:
   print("Wednesday")
if number == 4:
   print("Thursday")
if number == 5:
   print("Friday")
if number == 6:
   print("Saturday")

#exercise 2
days_slept= int(input("How many nights has your stay been"))
day_started = int(input("What is the date of the day you started"))
endweek= days_slept+ day_started%7 #im having trouble doing this problem

#exercise 3
#a > b logical opposite is a<=b
#a >= b logical opposite is a<b
#a >= 18  and  day == 3 logical opposite is a< 18 and day !=3
#a >= 18  and  day != 3 logical opposite is a< 18 and day ==3

#exercise 4
#3 == 3 True
#3 != 3 False
#3 >= 4 False
#not (3 < 4) False




