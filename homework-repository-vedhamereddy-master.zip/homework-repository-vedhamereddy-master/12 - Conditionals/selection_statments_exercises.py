#exercise 1
number = int(input("Please type in a number."))
if number >= 0 or number < 0:
    #print(number)

#exercise 2
age =int(input("Please input your age."))
if age > 20 or age < 20:
    #print(age)

#exercise 3
price = int(input("enter price of food"))
if price > 4:
    hst = price*0.13
    print ("McDs Receipt")
    print ("-------------")
    print ("Meal \t\t ${0:.2f}" .format (price))
    print ("\t\t -----")
    print ("Tax (13%) \t ${0:.2f}".format (hst))
    print ("\t\t -----")
    total = (price + hst)
    print ("TOTAL \t\t ${0:.2f}" .format (total))
    print ("\t\t -----")
if price < 4:
    print("McDs Receipt")
    print("-------------")
    print("Meal \t\t ${0:.2f}".format(price))
    print("\t\t -----")
    total = (price)
    print("TOTAL \t\t ${0:.2f}".format(total))
    print("\t\t -----")

#exercise 4
print ("Mailing within Canada \t           option 1")
print ("Mailing to USA \t                   option 2")
print ("Mailing Internationally \t       option 3")

option = int(input("Please enter the number of the option you wish to choose."))
if option == 1:
    print("The price for this is $0.85")
if option == 2:
    print("The price for this is $1.20")
if option == 3:
    print("The price for this is $2.50")