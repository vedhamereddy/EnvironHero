#exercise 4
a = int(input("Please enter the length of the first side: "))
b = int(input("Please enter the length of the second side: "))
c = int(input("Please enter the length of the third side: "))
if (a**2 + b**2 == c**2) or (c**2 + b**2 == a**2) or (a**2 +c**2 == b**2) or (c**2 + a**2 == b**2) or (b**2 + a**2 == c**2) or (b**2 + c**2 == a**2):
	print("This is a right triangle")
elif a == b == c:
	print("This is an equilateral triangle")
elif a==b or a==c or c==b:
	print("This is an isosceles triangle")
else:
	print("This is a scalene triangle")

#exercise 5
weight = int(input("Please enter the weight of the letter in grams: "))
if weight <= 30:
	print("The total price is $0.48")
else weight <= 50:
	print("The total price is $0.70")
elif weight <= 100:
	print("The total price is $0.90")

#exercise 6
suit = int(input("Please enter the number of the card: "))
newval = 0
if suit == 1 or suit ==14 or suit ==27 or suit ==40:
	newval = 1

if suit == 2 or suit ==15 or suit ==28 or suit ==41:
	newval = 2

if suit == 3 or suit ==16 or suit ==29 or suit ==42:
	newval = 3

if suit == 4 or suit ==17 or suit ==30 or suit ==43:
	newval = 4

if suit == 5 or suit ==18 or suit ==31 or suit ==44:
	newval = 5

if suit == 6 or suit ==19 or suit ==32 or suit ==45:
	newval = 6

if suit == 7 or suit ==20 or suit ==33 or suit ==46:
	newval = 7

if suit == 8 or suit ==21 or suit ==34 or suit ==47:
	newval = 8

if suit == 9 or suit ==22 or suit ==35 or suit ==48:
	newval = 9

if suit == 10 or suit ==23 or suit ==36 or suit ==49:
	newval = 10

if suit == 11 or suit ==24 or suit ==37 or suit ==50:
	newval = ("Jack")

if suit == 12 or suit ==25 or suit ==38 or suit ==51:
	newval = ("Queen")

if suit == 13 or suit ==26 or suit ==39 or suit ==52:
	 newval = ("King")

if suit >= 1 and suit <= 13:
	print("This is a ",newval, " of Hearts")
elif suit >= 14 and suit <= 26:
	print("This is a ",newval, " of Diamonds")
elif suit >= 27 and suit <= 39:
	print("This is a ",newval, " of Spades")
elif suit >= 40 and suit <= 52:
	print("This is a ",newval, " of Clubs")




