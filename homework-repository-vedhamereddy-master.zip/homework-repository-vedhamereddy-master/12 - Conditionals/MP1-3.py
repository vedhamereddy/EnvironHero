#exercise 1
number = int(input("Please enter a number: "))
if number % 2 == 0:
   print(number,"is even")
else:
   print(number,"is odd")

#exercise 2
numb = int(input("Please enter a number: "))
print(abs(numb))

#exercise 3
month = int(input("Please enter the number of the month: "))
if month == 1:
    print("There are 31 days in this month")
if month == 2:
    print("There are 28 days in this month")
if month == 3:
    print("There are 31 days in this month")
if month == 4:
    print("There are 30 days in this month")
if month == 5:
    print("There are 31 days in this month")
if month == 6:
    print("There are 30 days in this month")
if month == 7:
    print("There are 31 days in this month")
if month == 8:
    print("There are 31 days in this month")
if month == 9:
    print("There are 30 days in this month")
if month == 10:
    print("There are 31 days in this month")
if month == 11:
    print("There are 30 days in this month")
if month == 12:
    print("There are 31 days in this month")